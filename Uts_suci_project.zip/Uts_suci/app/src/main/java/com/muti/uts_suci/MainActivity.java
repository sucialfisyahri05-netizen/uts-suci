package com.muti.uts_suci;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imgFotoProfil = findViewById(R.id.imgFotoProfil);
        TextView tvNama = findViewById(R.id.tvNama);
        TextView tvUsername = findViewById(R.id.tvUsername);
        TextView tvBio = findViewById(R.id.tvBio);
        TextView tvNegara = findViewById(R.id.tvNegara);

        imgFotoProfil.setImageResource(R.drawable.foto_suci);
        tvNama.setText("Suci");
        tvUsername.setText("@suci");
        tvBio.setText("Welcome to my profile!");
        tvNegara.setText("Indonesia");
    }
}
